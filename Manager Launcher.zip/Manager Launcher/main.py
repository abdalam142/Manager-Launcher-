#!/usr/bin/env python3
import sys
import os
import signal
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ui.main_window import ManagerLauncherWindow

def main():
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    
    # Crucial for Wayland/GNOME to associate the process with the .desktop file's icon
    GLib.set_prgname('org.kali.ManagerLauncher')
    GLib.set_application_name('Manager Launcher')
    
    app = Gtk.Application(application_id='org.kali.ManagerLauncher')
    
    def on_activate(app):
        win = ManagerLauncherWindow(application=app)
        win.present()
    
    app.connect('activate', on_activate)
    return app.run(sys.argv)

if __name__ == '__main__':
    sys.exit(main())
