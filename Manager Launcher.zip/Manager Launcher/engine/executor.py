import subprocess
import os

def launch_app(app_data):
    # Desktop files store execution args in 'exec' while portable ones just use the path
    command = app_data.get('exec', '') if app_data.get('type') == 'desktop' else app_data.get('exec_path', '')
    if not command:
        return False
        
    is_terminal = app_data.get('is_terminal', False)
    
    # Strip desktop file placeholders
    for arg in ['%U', '%u', '%F', '%f', '%c', '%k']:
        command = command.replace(arg, '')
        
    command = command.strip()

    try:
        if app_data.get('type') == 'desktop':
            # Rely entirely on gio launch for correct desktop file execution (solves GUI app issues)
            subprocess.Popen(['gio', 'launch', app_data.get('exec_path', '')], start_new_session=True)
        elif is_terminal:
            # Open new terminal window and run
            subprocess.Popen(['gnome-terminal', '--', 'bash', '-c', f'{command}; exec bash'])
        else:
            # Launch directly
            subprocess.Popen(command, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        return True
    except Exception as e:
        print(f"Error launching {command}: {e}")
        return False
