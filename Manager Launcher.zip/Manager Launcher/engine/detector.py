import os
import configparser
import threading
from pathlib import Path

def parse_desktop_file(filepath):
    config = configparser.ConfigParser(interpolation=None)
    try:
        config.read(filepath)
        if 'Desktop Entry' in config:
            entry = config['Desktop Entry']
            if entry.get('NoDisplay', 'false').lower() == 'true':
                return None
            
            # Default to GUI unless Terminal is explicitly true
            is_term = entry.get('Terminal', 'false').lower() == 'true'
            
            return {
                'name': entry.get('Name', 'Unknown'),
                'exec': entry.get('Exec', ''),
                'icon': entry.get('Icon', 'application-x-executable'),
                'is_terminal': is_term,
                'exec_path': filepath,
                'type': 'desktop',
                'category': 'system'
            }
    except:
        pass
    return None

class AppDetector:
    def __init__(self, db):
        self.db = db
        self.running = False
        self.on_scan_finished = None
        
    def scan_installed_apps(self):
        desktop_dirs = [
            '/usr/share/applications',
            os.path.expanduser('~/.local/share/applications'),
            '/usr/local/share/applications',
            '/var/lib/snapd/desktop/applications'
        ]
        
        seen = set()
        for d in desktop_dirs:
            if not os.path.isdir(d):
                continue
            for file in os.listdir(d):
                if file.endswith('.desktop'):
                    path = os.path.join(d, file)
                    app = parse_desktop_file(path)
                    if app and app['exec']:
                        exec_base = app['exec'].split()[0].replace('"%F"', '').replace('%f', '').replace('%U', '').replace('%u', '')
                        if exec_base not in seen:
                            seen.add(exec_base)
                            self.db.insert_or_update_app(app)

    def scan_user_directory(self):
        # Scan typical places a user might put executables
        targets = [
            os.path.expanduser('~/Downloads'),
            os.path.expanduser('~/Applications'),
            os.path.expanduser('~/Desktop')
        ]
        
        for d in targets:
            if not os.path.isdir(d):
                continue
            for root, dirs, files in os.walk(d):
                # Don't go too deep
                if root[len(d):].count(os.sep) > 2:
                    continue
                for file in files:
                    p = os.path.join(root, file)
                    if os.access(p, os.X_OK) and not os.path.isdir(p):
                        # Heuristics: Skip common non-apps
                        if p.endswith('.so') or p.endswith('.a') or p.endswith('.o'):
                            continue
                        
                        if p.lower().endswith('.appimage'):
                            self.db.insert_or_update_app({
                                'name': file,
                                'exec_path': p,
                                'icon': 'application-x-executable',
                                'is_terminal': False,
                                'type': 'appimage',
                                'category': 'portable'
                            })
                        elif not file.startswith('.'):
                            try:
                                with open(p, 'rb') as f:
                                    header = f.read(4)
                                    if header.startswith(b'\x7fELF') or header.startswith(b'#!'):
                                        self.db.insert_or_update_app({
                                            'name': file,
                                            'exec_path': p,
                                            'icon': 'application-x-executable',
                                            'is_terminal': True, # Default custom scripts/ELFs to terminal unless specified
                                            'type': 'executable',
                                            'category': 'portable'
                                        })
                            except:
                                pass

    def run_scan(self):
        self.scan_installed_apps()
        self.scan_user_directory()
        self.running = False
        if self.on_scan_finished:
            self.on_scan_finished()

    def start_background_scan(self):
        if not self.running:
            self.running = True
            t = threading.Thread(target=self.run_scan, daemon=True)
            t.start()
