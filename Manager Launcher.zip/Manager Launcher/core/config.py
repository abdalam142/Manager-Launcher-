import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / 'data'
DATA_DIR.mkdir(exist_ok=True)
DB_PATH = DATA_DIR / 'manager.db'

# UI Constants
COLORS = {
    'bg': '#020510',          # Very dark blue, almost black
    'fg': '#ffffff',
    'search_bg': '#12182b',
    'item_bg': '#0a0f1c',
    'item_hover': '#16203a'
}
