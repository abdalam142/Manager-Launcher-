import sqlite3
import os
from .config import DB_PATH

class DatabaseManager:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._create_tables()

    def _create_tables(self):
        with self.conn:
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS apps (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    exec_path TEXT NOT NULL,
                    icon TEXT,
                    is_terminal BOOLEAN NOT NULL DEFAULT 0,
                    type TEXT,
                    last_used TIMESTAMP,
                    usage_count INTEGER DEFAULT 0,
                    is_custom BOOLEAN DEFAULT 0,
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    category TEXT,
                    is_pinned BOOLEAN DEFAULT 0
                )
            ''')
            
            # Add is_pinned to existing databases
            try:
                self.conn.execute('ALTER TABLE apps ADD COLUMN is_pinned BOOLEAN DEFAULT 0')
            except sqlite3.OperationalError:
                pass
            self.conn.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_exec_path ON apps(exec_path)')

    def insert_or_update_app(self, app_data):
        with self.conn:
            try:
                self.conn.execute('''
                    INSERT INTO apps (name, exec_path, icon, is_terminal, type, is_custom, category)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (app_data['name'], app_data['exec_path'], app_data.get('icon', ''),
                      app_data.get('is_terminal', False), app_data.get('type', 'system'),
                      app_data.get('is_custom', False), app_data.get('category', '')))
            except sqlite3.IntegrityError:
                pass
                
    def get_all_apps(self):
        cursor = self.conn.execute('SELECT * FROM apps ORDER BY usage_count DESC, added_at DESC')
        return [dict(row) for row in cursor.fetchall()]

    def record_launch(self, exec_path):
        with self.conn:
            self.conn.execute('''
                UPDATE apps
                SET usage_count = usage_count + 1, last_used = CURRENT_TIMESTAMP
                WHERE exec_path = ?
            ''', (exec_path,))

    def remove_app(self, exec_path):
        with self.conn:
            self.conn.execute('DELETE FROM apps WHERE exec_path = ?', (exec_path,))

    def toggle_pin_app(self, exec_path):
        with self.conn:
            self.conn.execute('''
                UPDATE apps
                SET is_pinned = NOT is_pinned
                WHERE exec_path = ?
            ''', (exec_path,))
