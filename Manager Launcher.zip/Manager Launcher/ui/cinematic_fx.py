import math
import cairo
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

class CinematicBackground(Gtk.DrawingArea):
    def __init__(self):
        super().__init__()
        self.time = 0
        self.set_size_request(800, 600)
        GLib.timeout_add(50, self.on_timeout)

    def on_timeout(self):
        self.time += 0.05
        self.queue_draw()
        return True

    def do_draw(self, cr):
        width = self.get_allocated_width()
        height = self.get_allocated_height()

        # Pure black background for maximum shadow contrast
        cr.set_source_rgb(0.0, 0.0, 0.0) 
        cr.paint()

        cr.save()
        pat1 = cairo.LinearGradient(0, height, width/2, 0) # Bottom up diffuse
        alpha1 = 0.15 + 0.05 * math.sin(self.time)
        pat1.add_color_stop_rgba(0, 0.0, 0.6, 1.0, alpha1 * 1.5) # Brighter core
        pat1.add_color_stop_rgba(0.5, 0.0, 0.3, 0.8, alpha1)
        pat1.add_color_stop_rgba(1, 0.0, 0.1, 0.4, 0)
        cr.set_source(pat1)
        cr.rectangle(0, 0, width, height)
        cr.fill()
        
        # Soft blurred light from left
        pat_left = cairo.RadialGradient(0, height/2, 10, 0, height/2, width*0.8)
        pat_left.add_color_stop_rgba(0, 0.0, 0.8, 1.0, 0.15 + 0.05 * math.cos(self.time*0.5))
        pat_left.add_color_stop_rgba(1, 0.0, 0.2, 0.6, 0)
        cr.set_source(pat_left)
        cr.rectangle(0, 0, width, height)
        cr.fill()
        cr.restore()
        
        cr.save()
        # High contrast blurred light from right
        pat2 = cairo.RadialGradient(width, height, 50, width, height, width*0.9)
        alpha2 = 0.15 + 0.05 * math.cos(self.time*0.8)
        pat2.add_color_stop_rgba(0, 1.0, 0.3, 0.0, alpha2 * 1.5) # Intense orange core
        pat2.add_color_stop_rgba(0.6, 1.0, 0.2, 0.0, alpha2)
        pat2.add_color_stop_rgba(1, 0.3, 0.0, 0.0, 0)
        cr.set_source(pat2)
        cr.rectangle(0, 0, width, height)
        cr.fill()
        
        # Subtle floor reflection gradient at the bottom
        pat_floor = cairo.LinearGradient(0, height - 80, 0, height)
        pat_floor.add_color_stop_rgba(0, 1, 1, 1, 0)
        pat_floor.add_color_stop_rgba(1, 0.3, 0.5, 0.8, 0.1)
        cr.set_source(pat_floor)
        cr.rectangle(0, height - 80, width, 80)
        cr.fill()
        cr.restore()
