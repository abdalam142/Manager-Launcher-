#!/bin/bash
DIR="$( cd "$( dirname "$(readlink -f "${BASH_SOURCE[0]}")" )" && pwd )"
nohup python3 "$DIR/main.py" &>/dev/null &
