import gi
import os
import threading
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, Pango
from ui.cinematic_fx import CinematicBackground
from core.db import DatabaseManager
from engine.detector import AppDetector
from engine.executor import launch_app
from core.config import COLORS

class ManagerLauncherWindow(Gtk.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.set_title("Manager Launcher")
        self.set_default_size(1000, 700)
        self.set_position(Gtk.WindowPosition.CENTER)
        
        try:
            icon_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data', 'icon.png'))
            if os.path.exists(icon_path):
                self.set_icon_from_file(icon_path)
            else:
                self.set_icon_name('application-x-executable')
        except:
            pass
        
        # Dimming event handlers for the cinematic effect
        self.add_events(Gdk.EventMask.ENTER_NOTIFY_MASK | Gdk.EventMask.LEAVE_NOTIFY_MASK)
        self.connect('enter-notify-event', self.on_mouse_enter)
        self.connect('leave-notify-event', self.on_mouse_leave)
        
        self.db = DatabaseManager()
        self.detector = AppDetector(self.db)
        self.detector.on_scan_finished = self.on_initial_scan_finished
        self.detector.start_background_scan()
        
        self.setup_css()
        
        overlay = Gtk.Overlay()
        self.add(overlay)
        
        bg = CinematicBackground()
        overlay.add(bg)
        
        self.main_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        self.main_container.set_name("main-container")
        self.main_container.set_margin_top(20)
        self.main_container.set_margin_bottom(20)
        self.main_container.set_margin_start(20)
        self.main_container.set_margin_end(20)
        overlay.add_overlay(self.main_container)
        
        top_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text("Search installed or portable executable apps...")
        self.search_entry.connect('search-changed', self.on_search_changed)
        top_bar.pack_start(self.search_entry, True, True, 0)
        
        self.add_btn = Gtk.Button(label="+ Add Custom")
        self.add_btn.connect("clicked", lambda w: self.on_add_clicked())
        self.add_btn.get_style_context().add_class('suggested-action')
        top_bar.pack_start(self.add_btn, False, False, 0)
        
        self.bind_cmd_btn = Gtk.Button(label="+ Bind Command")
        self.bind_cmd_btn.connect("clicked", self.on_bind_command_clicked)
        self.bind_cmd_btn.get_style_context().add_class('suggested-action')
        self.bind_cmd_btn.set_tooltip_text("Save text in search bar as a command and run in terminal")
        top_bar.pack_start(self.bind_cmd_btn, False, False, 0)
        
        self.toggle_stack_btn = Gtk.Button(label="All Apps")
        self.toggle_stack_btn.connect("clicked", self.on_toggle_stack)
        self.toggle_stack_btn.get_style_context().add_class('suggested-action')
        top_bar.pack_start(self.toggle_stack_btn, False, False, 0)
        
        self.main_container.pack_start(top_bar, False, False, 0)
        
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.stack.set_transition_duration(400)
        
        # Page 1: Pinned Apps View
        self.pinned_list = Gtk.ListBox()
        self.pinned_list.get_style_context().add_class('app-list')
        scroll_pinned = Gtk.ScrolledWindow()
        scroll_pinned.add(self.pinned_list)
        
        pinned_frame = Gtk.Frame()
        pinned_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        
        pinned_header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        pinned_header_box.set_margin_top(15)
        pinned_header_box.set_margin_bottom(10)
        pinned_header_box.set_margin_start(10)
        pinned_header_box.set_margin_end(10)
        
        lbl_pinned = Gtk.Label(label="<span font='14' weight='bold' color='white'>Main Pinned Applications</span>", use_markup=True)
        pinned_edit_btn = Gtk.Button(label="Edit Pinned")
        pinned_edit_btn.connect("clicked", self.on_edit_pinned_clicked)
        pinned_edit_btn.get_style_context().add_class('suggested-action')
        
        pinned_header_box.pack_start(lbl_pinned, False, False, 0)
        pinned_header_box.pack_end(pinned_edit_btn, False, False, 0)
        
        pinned_box.pack_start(pinned_header_box, False, False, 0)
        pinned_box.pack_start(scroll_pinned, True, True, 0)
        pinned_frame.add(pinned_box)
        
        self.stack.add_named(pinned_frame, "pinned")
        
        # Page 2: All Apps View
        panels_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        
        self.gui_list = Gtk.ListBox()
        self.gui_list.get_style_context().add_class('app-list')
        scroll_gui = Gtk.ScrolledWindow()
        scroll_gui.add(self.gui_list)
        
        gui_frame = Gtk.Frame()
        gui_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        gui_header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        gui_header_box.set_margin_top(15)
        gui_header_box.set_margin_bottom(10)
        gui_header_box.set_margin_start(10)
        gui_header_box.set_margin_end(10)
        lbl_gui = Gtk.Label(label="<span font='14' weight='bold' color='white'>GUI Applications</span>", use_markup=True)
        gui_add_btn = Gtk.Button(label="+ Add")
        gui_add_btn.connect("clicked", lambda w: self.on_add_clicked(is_terminal=False))
        gui_add_btn.get_style_context().add_class('suggested-action')
        gui_header_box.pack_start(lbl_gui, False, False, 0)
        gui_header_box.pack_end(gui_add_btn, False, False, 0)
        gui_box.pack_start(gui_header_box, False, False, 0)
        gui_box.pack_start(scroll_gui, True, True, 0)
        gui_frame.add(gui_box)
        panels_box.pack_start(gui_frame, True, True, 0)
        
        self.cli_list = Gtk.ListBox()
        self.cli_list.get_style_context().add_class('app-list')
        scroll_cli = Gtk.ScrolledWindow()
        scroll_cli.add(self.cli_list)
        
        cli_frame = Gtk.Frame()
        cli_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        cli_header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        cli_header_box.set_margin_top(15)
        cli_header_box.set_margin_bottom(10)
        cli_header_box.set_margin_start(10)
        cli_header_box.set_margin_end(10)
        lbl_cli = Gtk.Label(label="<span font='14' weight='bold' color='white'>Terminal Applications</span>", use_markup=True)
        cli_add_btn = Gtk.Button(label="+ Add")
        cli_add_btn.connect("clicked", lambda w: self.on_add_clicked(is_terminal=True))
        cli_add_btn.get_style_context().add_class('suggested-action')
        cli_header_box.pack_start(lbl_cli, False, False, 0)
        cli_header_box.pack_end(cli_add_btn, False, False, 0)
        cli_box.pack_start(cli_header_box, False, False, 0)
        cli_box.pack_start(scroll_cli, True, True, 0)
        cli_frame.add(cli_box)
        panels_box.pack_start(cli_frame, True, True, 0)
        
        self.stack.add_named(panels_box, "all")
        
        self.main_container.pack_start(self.stack, True, True, 0)

        # Bottom Bar: Recent apps & Spinner
        self.recent_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.recent_box.set_margin_top(10)
        lbl_recent = Gtk.Label(label="<span size='large' color='gray'>Recently Used:</span>", use_markup=True)
        self.recent_box.pack_start(lbl_recent, False, False, 0)
        
        close_btn = Gtk.Button.new_from_icon_name('window-close-symbolic', Gtk.IconSize.MENU)
        close_btn.set_tooltip_text("Close Launcher")
        close_btn.connect("clicked", lambda w: self.close())
        close_btn.get_style_context().add_class('system-action')
        
        restart_btn = Gtk.Button.new_from_icon_name('view-refresh-symbolic', Gtk.IconSize.MENU)
        restart_btn.set_tooltip_text("Restart Launcher")
        restart_btn.connect("clicked", self.on_restart_clicked)
        restart_btn.get_style_context().add_class('system-action')
        
        self.recent_box.pack_end(close_btn, False, False, 0)
        self.recent_box.pack_end(restart_btn, False, False, 0)
        
        self.spinner = Gtk.Spinner()
        self.recent_box.pack_end(self.spinner, False, False, 0)
        
        self.main_container.pack_start(self.recent_box, False, False, 0)

        self.populate_lists()
        self.show_all()
        
    def on_initial_scan_finished(self):
        GLib.idle_add(self.populate_lists, self.search_entry.get_text())

    def on_toggle_stack(self, widget):
        current = self.stack.get_visible_child_name()
        if current == "pinned":
            self.stack.set_visible_child_name("all")
            self.toggle_stack_btn.set_label("Back")
        else:
            self.stack.set_visible_child_name("pinned")
            self.toggle_stack_btn.set_label("All Apps")
            
    def on_restart_clicked(self, widget):
        import sys
        os.execl(sys.executable, sys.executable, *sys.argv)

    def on_mouse_enter(self, widget, event):
        if event.detail != Gdk.NotifyType.INFERIOR:
            self.main_container.get_style_context().remove_class('dimmed')

    def on_mouse_leave(self, widget, event):
        if event.detail != Gdk.NotifyType.INFERIOR:
            self.main_container.get_style_context().add_class('dimmed')

    def setup_css(self):
        css = f'''
        window {{ background-color: #010206; border-radius: 12px; }}
        #main-container {{
            transition: opacity 0.4s ease-in-out;
            opacity: 1.0;
        }}
        #main-container.dimmed {{
            opacity: 0.1;
        }}
        entry {{
            background-color: rgba(20, 25, 40, 0.8);
            color: white;
            border-radius: 8px;
            padding: 12px;
            border: 1px solid #2a3556;
        }}
        frame {{
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            background-color: rgba(10, 15, 30, 0.4);
        }}
        .app-list {{ background-color: transparent; }}
        eventbox {{
            padding: 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            color: white;
            transition: all 0.2s ease-in-out;
        }}
        eventbox:hover {{ background-color: rgba(40, 60, 100, 0.5); border-radius: 6px; }}
        button.suggested-action {{
            background-color: #1a4b8c;
            color: white;
            border-radius: 8px;
            padding: 10px;
        }}
        button.suggested-action:hover {{ background-color: #2a5cac; }}
        button.destructive-action {{ background-color: #8c1a1a; color: white; }}
        button.system-action {{
            background-color: transparent;
            color: gray;
            border: none;
            padding: 4px;
        }}
        button.system-action:hover {{
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 6px;
        }}
        scrollbars {{ opacity: 0.2; }}
        '''
        provider = Gtk.CssProvider()
        provider.load_from_data(css.encode('utf-8'))
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

    def populate_lists(self, search_text=""): 
        for child in self.gui_list.get_children():
            self.gui_list.remove(child)
        for child in self.cli_list.get_children():
            self.cli_list.remove(child)
        for child in self.pinned_list.get_children():
            self.pinned_list.remove(child)
            
        apps = self.db.get_all_apps()
        search_text = search_text.lower()
        
        for app in apps:
            if search_text and search_text not in app['name'].lower():
                continue
                
            row = self.create_app_row(app)
            if app['is_terminal']:
                self.cli_list.add(row)
            else:
                self.gui_list.add(row)
                
            if app.get('is_pinned'):
                # We need fresh widgets for the second list because GTK widgets can only have one parent
                pinned_row = self.create_app_row(app)
                self.pinned_list.add(pinned_row)
                
        self.gui_list.show_all()
        self.cli_list.show_all()
        self.pinned_list.show_all()

    def create_app_row(self, app):
        row = Gtk.ListBoxRow()
        event_box = Gtk.EventBox()
        event_box.connect('button-press-event', self.on_app_button_press, app, row)
        
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        
        icon_theme = Gtk.IconTheme.get_default()
        icon_name = app.get('icon', 'application-x-executable')
        if not icon_name or not icon_theme.has_icon(icon_name):
            icon_name = 'application-x-executable'
        
        icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DND)
        box.pack_start(icon, False, False, 0)
        
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        lbl = Gtk.Label(label=f"<span size='large' color='white'>{app['name']}</span>", use_markup=True)
        lbl.set_halign(Gtk.Align.START)
        vbox.pack_start(lbl, True, True, 0)
        
        path_lbl = Gtk.Label(label=f"<span size='small' color='#666666'>{app['exec_path']}</span>", use_markup=True)
        path_lbl.set_halign(Gtk.Align.START)
        path_lbl.set_ellipsize(Pango.EllipsizeMode.END)
        vbox.pack_start(path_lbl, False, False, 0)
        
        box.pack_start(vbox, True, True, 0)
        
        usage_text = f"Used {app['usage_count']} times" if app['usage_count'] > 0 else "Never used"
        usage_lbl = Gtk.Label(label=f"<span size='small' color='gray'>{usage_text}</span>", use_markup=True)
        box.pack_start(usage_lbl, False, False, 0)
        
        event_box.add(box)
        row.add(event_box)
        return row

    def on_search_changed(self, entry):
        self.populate_lists(entry.get_text())
        
    def on_add_clicked(self, is_terminal=False):
        dialog = Gtk.FileChooserDialog(
            title="Please choose EXECUTABLE files", parent=self,
            action=Gtk.FileChooserAction.OPEN,
            buttons=(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OPEN, Gtk.ResponseType.OK))
        dialog.set_select_multiple(True)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            filenames = dialog.get_filenames()
            for filename in filenames:
                app = {
                    'name': os.path.basename(filename),
                    'exec_path': filename,
                    'icon': 'application-x-executable',
                    'is_terminal': is_terminal,
                    'type': 'custom',
                    'is_custom': True,
                    'is_pinned': False
                }
                self.db.insert_or_update_app(app)
            self.populate_lists(self.search_entry.get_text())
        dialog.destroy()
        
    def on_bind_command_clicked(self, widget):
        text = self.search_entry.get_text().strip()
        if not text:
            dialog = Gtk.MessageDialog(
                transient_for=self, flags=0, message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK, text="Please enter a terminal command in the search bar first."
            )
            dialog.run()
            dialog.destroy()
            return

        command_name = text.split(" ")[0] if " " in text else text

        app = {
            'name': f"Cmd: {command_name}",
            'exec_path': text,
            'icon': 'utilities-terminal',
            'is_terminal': True,
            'type': 'custom',
            'is_custom': True,
            'is_pinned': True
        }
        self.db.insert_or_update_app(app)
        
        # Run the command immediately
        self.spinner.start()
        self.spinner.show()
        launch_app(app)
        self.db.record_launch(app['exec_path'])
        
        
        self.populate_lists()
        self.search_entry.set_text("")
        GLib.timeout_add(1500, self.stop_spinner)

    def on_edit_pinned_clicked(self, widget):
        dialog = Gtk.Dialog(title="Edit Pinned Applications", transient_for=self, flags=0)
        dialog.add_buttons(Gtk.STOCK_CLOSE, Gtk.ResponseType.CLOSE)
        dialog.set_default_size(500, 400)
        
        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        
        lbl = Gtk.Label(label="Manage your pinned applications and commands here.")
        box.pack_start(lbl, False, False, 0)
        
        listbox = Gtk.ListBox()
        scroll = Gtk.ScrolledWindow()
        scroll.add(listbox)
        box.pack_start(scroll, True, True, 0)
        
        apps = [a for a in self.db.get_all_apps() if a.get('is_pinned')]
        for app in apps:
            row = Gtk.ListBoxRow()
            rbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            
            icon_theme = Gtk.IconTheme.get_default()
            icon_name = app.get('icon', 'application-x-executable')
            if not icon_name or not icon_theme.has_icon(icon_name):
                icon_name = 'application-x-executable'
            icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DND)
            rbox.pack_start(icon, False, False, 0)

            llbl = Gtk.Label(label=app['name'])
            llbl.set_halign(Gtk.Align.START)
            rbox.pack_start(llbl, True, True, 0)
            
            unpin_btn = Gtk.Button(label="Unpin")
            unpin_btn.connect("clicked", self.on_dialog_unpin_clicked, app, row, listbox)
            rbox.pack_end(unpin_btn, False, False, 0)
            
            del_btn = Gtk.Button(label="Delete App")
            del_btn.get_style_context().add_class("destructive-action")
            del_btn.connect("clicked", self.on_dialog_delete_clicked, app, row, listbox)
            rbox.pack_end(del_btn, False, False, 0)
            
            row.add(rbox)
            listbox.add(row)
            
        dialog.show_all()
        dialog.run()
        dialog.destroy()
        self.populate_lists()

    def on_dialog_unpin_clicked(self, btn, app, row, listbox):
        self.db.toggle_pin_app(app['exec_path'])
        listbox.remove(row)
        
    def on_dialog_delete_clicked(self, btn, app, row, listbox):
        conf_dialog = Gtk.MessageDialog(
            transient_for=self, flags=0, message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Are you sure you want to permanently delete '{app['name']}'?"
        )
        conf_dialog.get_widget_for_response(Gtk.ResponseType.YES).get_style_context().add_class("destructive-action")
        response = conf_dialog.run()
        conf_dialog.destroy()
        if response == Gtk.ResponseType.YES:
            self.db.remove_app(app['exec_path'])
            listbox.remove(row)

    def on_app_button_press(self, event_box, event, app, row):
        if event.button == 1: 
            self.spinner.start()
            self.spinner.show()
            launch_app(app)
            self.db.record_launch(app['exec_path'])
            self.populate_lists(self.search_entry.get_text())
            GLib.timeout_add(1500, self.stop_spinner)
            
        elif event.button == 3:
            menu = Gtk.Menu()
            
            run_item = Gtk.MenuItem(label="Run")
            run_item.connect("activate", lambda w: self.on_app_button_press(event_box, Gdk.EventButton(button=1), app, row))
            menu.append(run_item)
            
            pin_label = "Unpin from Main View" if app.get('is_pinned') else "Pin to Main View"
            pin_item = Gtk.MenuItem(label=pin_label)
            pin_item.connect("activate", self.on_pin_toggled, app)
            menu.append(pin_item)
            
            remove_item = Gtk.MenuItem(label="Remove App")
            remove_item.connect("activate", self.on_remove_clicked, app, row)
            menu.append(remove_item)
            
            menu.show_all()
            menu.popup(None, None, None, None, event.button, event.time)

    def stop_spinner(self):
        self.spinner.stop()
        self.spinner.hide()
        return False

    def on_pin_toggled(self, widget, app):
        self.db.toggle_pin_app(app['exec_path'])
        self.populate_lists(self.search_entry.get_text())

    def on_remove_clicked(self, widget, app, row):
        dialog = Gtk.MessageDialog(
            transient_for=self, flags=0, message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.OK_CANCEL,
            text=f"First Warning: Are you sure you want to remove '{app['name']}' from the launcher?"
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.OK:
            dialog2 = Gtk.MessageDialog(
                transient_for=self, flags=0, message_type=Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.YES_NO,
                text=f"Final Warning: Delete '{app['name']}' permanently from Manager Launcher?"
            )
            dialog2.get_widget_for_response(Gtk.ResponseType.YES).get_style_context().add_class("destructive-action")
            res2 = dialog2.run()
            dialog2.destroy()
            
            if res2 == Gtk.ResponseType.YES:
                self.db.remove_app(app['exec_path'])
                self.populate_lists(self.search_entry.get_text())
