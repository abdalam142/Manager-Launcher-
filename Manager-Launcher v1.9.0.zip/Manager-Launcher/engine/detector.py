import os
import configparser
import threading
from pathlib import Path

def parse_desktop_file(filepath):
    try:
        in_desktop_entry = False
        app_data = {
            'name': 'Unknown',
            'exec': '',
            'icon': 'application-x-executable',
            'is_terminal': False,
            'exec_path': filepath,
            'type': 'desktop',
            'category': 'system',
            'file_mtime': os.path.getmtime(filepath)
        }
        no_display = False
        
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if line == '[Desktop Entry]':
                    in_desktop_entry = True
                    continue
                elif line.startswith('['):
                    in_desktop_entry = False
                    continue
                    
                if in_desktop_entry and '=' in line:
                    # Only take exactly the key without qualifiers like [ar]
                    parts = line.split('=', 1)
                    key = parts[0].strip()
                    val = parts[1].strip()
                    
                    if key == 'Name':
                        app_data['name'] = val
                    elif key == 'Exec':
                        app_data['exec'] = val
                    elif key == 'Icon':
                        app_data['icon'] = val
                    elif key == 'Terminal':
                        app_data['is_terminal'] = val.lower() == 'true'
                    elif key == 'NoDisplay':
                        no_display = val.lower() == 'true'
                        
        if no_display or not app_data['exec']:
            return None
        return app_data
    except Exception:
        pass
    return None

class AppDetector:
    def __init__(self, db, on_app_discovered=None, on_scan_progress=None, on_scan_finished=None):
        self.db = db
        self.running = False
        self._stop_flag = False
        self.on_app_discovered = on_app_discovered
        self.on_scan_progress = on_scan_progress
        self.on_scan_finished = on_scan_finished
        self.batch_size = 50
        self.discovered_batch = []
        
    def stop_scan(self):
        self._stop_flag = True
        
    def emit_progress(self, text):
        if self.on_scan_progress:
            self.on_scan_progress(text)
            
    def emit_discovered(self, app):
        if self.on_app_discovered:
            self.on_app_discovered(app)

    def flush_batch(self):
        if self.discovered_batch:
            self.db.insert_apps_batch(self.discovered_batch)
            self.discovered_batch = []
        
    def scan_installed_apps(self):
        desktop_dirs = [
            '/usr/share/applications',
            os.path.expanduser('~/.local/share/applications'),
            '/usr/local/share/applications',
            '/var/lib/snapd/desktop/applications',
            '/var/lib/flatpak/exports/share/applications'
        ]
        
        # Binary directories to scan for "all" programs
        bin_dirs = [
            '/usr/bin',
            '/usr/local/bin',
            '/bin',
            '/sbin',
            '/usr/games'
        ]
        
        # Deep scan directories
        recursive_dirs = [
            '/opt'
        ]
        
        seen = set()
        for d in desktop_dirs:
            if self._stop_flag: break
            if not os.path.isdir(d):
                continue
            self.emit_progress(f"Scanning {d}...")
            for file in os.listdir(d):
                if self._stop_flag: break
                if file.endswith('.desktop'):
                    path = os.path.join(d, file)
                    app = parse_desktop_file(path)
                    if app and app['exec']:
                        exec_base = app['exec'].split()[0].replace('"', '').replace("'", "")
                        # Handle full paths in Exec
                        if not exec_base.startswith('/') and not os.path.exists(exec_base):
                            pass 

                        if exec_base not in seen:
                            seen.add(exec_base)
                            self.discovered_batch.append(app)
                            # Desktop apps are always shown in live list
                            self.emit_discovered(app)
                            
                            if len(self.discovered_batch) >= self.batch_size:
                                self.flush_batch()

        # 2. Scan Binary Directories
        for d in bin_dirs:
            if self._stop_flag: break
            if not os.path.isdir(d): continue
            self.emit_progress(f"Binaries: {d}...")
            try:
                files = os.listdir(d)
                for i, file in enumerate(files):
                    if self._stop_flag: break
                    p = os.path.join(d, file)
                    if os.access(p, os.X_OK) and not os.path.isdir(p):
                        mtime = os.path.getmtime(p)
                        app = {
                            'name': file,
                            'exec_path': p,
                            'icon': 'application-x-executable',
                            'is_terminal': True,
                            'type': 'bin',
                            'category': 'system',
                            'file_mtime': mtime
                        }
                        if p not in seen:
                            seen.add(p)
                            self.discovered_batch.append(app)
                            
                            # Only emit Discovery for every 25th binary to keep UI smooth
                            if i % 25 == 0:
                                self.emit_discovered(app)
                                self.emit_progress(f"Found {file}...")

                            if len(self.discovered_batch) >= self.batch_size:
                                self.flush_batch()
            except:
                continue

        # 3. Recursive Scan for /opt
        for d in recursive_dirs:
            if self._stop_flag: break
            if not os.path.isdir(d): continue
            for root, dirs, files in os.walk(d):
                if self._stop_flag: break
                self.emit_progress(f"Deep scan: {root}...")
                if root[len(d):].count(os.sep) > 3: continue 
                for file in files:
                    p = os.path.join(root, file)
                    if os.access(p, os.X_OK) and not os.path.isdir(p):
                        if p not in seen:
                            mtime = os.path.getmtime(p)
                            app = {
                                'name': file,
                                'exec_path': p,
                                'icon': 'application-x-executable',
                                'is_terminal': True,
                                'type': 'opt',
                                'category': 'system',
                                'file_mtime': mtime
                            }
                            seen.add(p)
                            self.discovered_batch.append(app)
                            
                            # Opt binaries are often real apps, show them periodically
                            if len(seen) % 20 == 0:
                                self.emit_discovered(app)

                            if len(self.discovered_batch) >= self.batch_size:
                                self.flush_batch()

    def scan_user_directory(self):
        # Scan typical places a user might put executables
        targets = [
            os.path.expanduser('~/Downloads'),
            os.path.expanduser('~/Applications'),
            os.path.expanduser('~/Desktop')
        ]
        
        for d in targets:
            if self._stop_flag: break
            if not os.path.isdir(d):
                continue
            self.emit_progress(f"Scanning {d}...")
            for root, dirs, files in os.walk(d):
                if self._stop_flag: break
                # Don't go too deep
                if root[len(d):].count(os.sep) > 2:
                    continue
                for file in files:
                    if self._stop_flag: break
                    p = os.path.join(root, file)
                    if os.access(p, os.X_OK) and not os.path.isdir(p):
                        # Heuristics: Skip common non-apps
                        if p.endswith('.so') or p.endswith('.a') or p.endswith('.o'):
                            continue
                        
                        app = None
                        mtime = os.path.getmtime(p)
                        if p.lower().endswith('.appimage'):
                            app = {
                                'name': file,
                                'exec_path': p,
                                'icon': 'application-x-executable',
                                'is_terminal': False,
                                'type': 'appimage',
                                'category': 'portable',
                                'file_mtime': mtime
                            }
                        elif not file.startswith('.'):
                            try:
                                with open(p, 'rb') as f:
                                    header = f.read(4)
                                    if header.startswith(b'\x7fELF') or header.startswith(b'#!'):
                                        app = {
                                            'name': file,
                                            'exec_path': p,
                                            'icon': 'application-x-executable',
                                            'is_terminal': True, 
                                            'type': 'executable',
                                            'category': 'portable',
                                            'file_mtime': mtime
                                        }
                            except:
                                pass
                        
                        if app:
                            self.discovered_batch.append(app)
                            self.emit_discovered(app)
                            
                            if len(self.discovered_batch) >= self.batch_size:
                                self.flush_batch()

    def run_scan(self):
        self.emit_progress("Starting scan...")
        self.scan_installed_apps()
        self.scan_user_directory()
        self.flush_batch()
        self.running = False
        
        if self._stop_flag:
            self.emit_progress("Scan stopped.")
        else:
            self.emit_progress("Scan completed.")
            
        if self.on_scan_finished:
            self.on_scan_finished()

    def start_background_scan(self):
        if not self.running:
            self.running = True
            self._stop_flag = False
            t = threading.Thread(target=self.run_scan, daemon=True)
            t.start()
