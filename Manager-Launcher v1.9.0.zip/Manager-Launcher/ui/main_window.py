import gi
import os
import threading
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, Pango, GdkPixbuf
from ui.cinematic_fx import CinematicBackground
from core.db import DatabaseManager
from engine.detector import AppDetector
from engine.executor import launch_app
from core.config import COLORS

class ManagerLauncherWindow(Gtk.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.set_title("Manager Launcher")
        self.set_default_size(1100, 700)
        self.set_size_request(600, 500) # Lower minimum size
        self.set_position(Gtk.WindowPosition.CENTER)
        
        try:
            icon_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data', 'icon.png'))
            if os.path.exists(icon_path):
                self.set_icon_from_file(icon_path)
            else:
                self.set_icon_name('application-x-executable')
        except:
            pass
        
        # Dimming event handlers for the cinematic effect
        self.add_events(Gdk.EventMask.ENTER_NOTIFY_MASK | Gdk.EventMask.LEAVE_NOTIFY_MASK)
        self.connect('enter-notify-event', self.on_mouse_enter)
        self.connect('leave-notify-event', self.on_mouse_leave)
        
        self.db = DatabaseManager()
        self.detector = AppDetector(
            self.db,
            on_app_discovered=self.on_app_discovered,
            on_scan_progress=self.on_scan_progress,
            on_scan_finished=self.on_initial_scan_finished
        )
        self._search_timeout_id = None
        # Scan is now only triggered by the "Scan System" button to preserve performance
        
        self.setup_css()
        
        # Fluid UI Scaling variables
        self.css_provider = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), self.css_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        
        # State for independent bidirectional sliding window (Virtual Scroller)
        self.gui_start_offset = 0
        self.gui_end_offset = 0
        self.cli_start_offset = 0
        self.cli_end_offset = 0
        self.loading_gui = False
        self.loading_cli = False
        self.current_search_text = ""
        self.WINDOW_SIZE = 800 # Fixed widgets in memory for zero heat
        self.BATCH_SIZE = 200
        self.ROW_HEIGHT = 65 # Estimated height for scroll compensation
        
        overlay = Gtk.Overlay()
        self.add(overlay)
        
        bg = CinematicBackground()
        overlay.add(bg)
        
        self.main_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        self.main_container.set_name("main-container")
        self.main_container.set_margin_top(20)
        self.main_container.set_margin_bottom(20)
        self.main_container.set_margin_start(20)
        self.main_container.set_margin_end(20)
        overlay.add_overlay(self.main_container)
        
        self.top_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text("Search apps...")
        self.search_entry.set_width_chars(5) # Allow extreme shrinking
        self.search_entry.connect('search-changed', self.on_search_changed)
        self.search_entry.set_valign(Gtk.Align.CENTER)
        self.top_bar.pack_start(self.search_entry, True, True, 0)
        
        # Consistent buttons in a horizontal line
        self.add_btn = Gtk.Button(label="+ Add Custom")
        self.add_btn.connect("clicked", lambda w: self.on_add_clicked())
        self.add_btn.get_style_context().add_class('suggested-action')
        self.top_bar.pack_start(self.add_btn, False, False, 0)
        
        self.bind_cmd_btn = Gtk.Button(label="+ Bind Command")
        self.bind_cmd_btn.connect("clicked", self.on_bind_command_clicked)
        self.bind_cmd_btn.get_style_context().add_class('suggested-action')
        self.bind_cmd_btn.set_tooltip_text("Save text in search bar as a command and run in terminal")
        self.top_bar.pack_start(self.bind_cmd_btn, False, False, 0)
        
        self.toggle_stack_btn = Gtk.Button(label="All Apps")
        self.toggle_stack_btn.connect("clicked", self.on_toggle_stack)
        self.toggle_stack_btn.get_style_context().add_class('suggested-action')
        self.top_bar.pack_start(self.toggle_stack_btn, False, False, 0)
        
        self.scan_btn = Gtk.Button(label="Scan System")
        self.scan_btn.connect("clicked", self.on_scan_clicked)
        self.scan_btn.get_style_context().add_class('suggested-action')
        self.scan_btn.set_tooltip_text("Scan your system to detect newly installed applications")
        self.top_bar.pack_start(self.scan_btn, False, False, 0)
        
        self.main_container.pack_start(self.top_bar, False, False, 0)
        
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.stack.set_transition_duration(250)
        
        # Page 1: Pinned Apps View
        self.pinned_list = Gtk.ListBox()
        self.pinned_list.get_style_context().add_class('app-list')
        scroll_pinned = Gtk.ScrolledWindow()
        scroll_pinned.add(self.pinned_list)
        
        pinned_frame = Gtk.Frame()
        pinned_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        
        pinned_header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        pinned_header_box.set_margin_top(15)
        pinned_header_box.set_margin_bottom(10)
        pinned_header_box.set_margin_start(10)
        pinned_header_box.set_margin_end(10)
        
        lbl_pinned = Gtk.Label(label="<span color='white'>Main Pinned Applications</span>", use_markup=True)
        lbl_pinned.get_style_context().add_class('title-lbl')
        pinned_edit_btn = Gtk.Button(label="Edit Pinned")
        pinned_edit_btn.connect("clicked", self.on_edit_pinned_clicked)
        pinned_edit_btn.get_style_context().add_class('suggested-action')
        
        pinned_header_box.pack_start(lbl_pinned, False, False, 0)
        pinned_header_box.pack_end(pinned_edit_btn, False, False, 0)
        
        pinned_box.pack_start(pinned_header_box, False, False, 0)
        pinned_box.pack_start(scroll_pinned, True, True, 0)
        pinned_frame.add(pinned_box)
        
        self.stack.add_named(pinned_frame, "pinned")
        
        # Page 2: All Apps View
        self.panels_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        
        self.gui_list = Gtk.ListBox()
        self.gui_list.get_style_context().add_class('app-list')
        scroll_gui = Gtk.ScrolledWindow()
        scroll_gui.add(self.gui_list)
        
        gui_frame = Gtk.Frame()
        gui_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        gui_header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        gui_header_box.set_margin_top(15)
        gui_header_box.set_margin_bottom(10)
        gui_header_box.set_margin_start(10)
        gui_header_box.set_margin_end(10)
        lbl_gui = Gtk.Label(label="<span color='white'>GUI Applications</span>", use_markup=True)
        lbl_gui.get_style_context().add_class('title-lbl')
        self.gui_range_lbl = Gtk.Label(label=" (1-1000)")
        
        gui_jump_top = Gtk.Button(label="↑ Prev 1000")
        gui_jump_top.connect("clicked", lambda w: self.on_paginate(is_terminal=False, forward=False))
        gui_jump_bottom = Gtk.Button(label="↓ Next 1000")
        gui_jump_bottom.connect("clicked", lambda w: self.on_paginate(is_terminal=False, forward=True))
        
        gui_add_btn = Gtk.Button(label="+ Add")
        gui_add_btn.connect("clicked", lambda w: self.on_add_clicked(is_terminal=False))
        gui_add_btn.get_style_context().add_class('suggested-action')
        
        gui_header_box.pack_start(lbl_gui, False, False, 0)
        gui_header_box.pack_start(self.gui_range_lbl, False, False, 0)
        
        # Spacer to push buttons to the right
        gui_spacer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        gui_spacer.set_hexpand(True)
        gui_header_box.pack_start(gui_spacer, True, True, 0)
        
        gui_header_box.pack_start(gui_jump_top, False, False, 0)
        gui_header_box.pack_start(gui_jump_bottom, False, False, 0)
        gui_header_box.pack_start(gui_add_btn, False, False, 0)
        
        gui_box.pack_start(gui_header_box, False, False, 0)
        gui_box.pack_start(scroll_gui, True, True, 0)
        
        # Connect scroll event for GUI list
        scroll_gui.get_vadjustment().connect("value-changed", self.on_gui_scroll)
        
        self.scroll_gui = scroll_gui # Keep reference 
        gui_frame.add(gui_box)
        self.panels_box.pack_start(gui_frame, True, True, 0)
        
        self.cli_list = Gtk.ListBox()
        self.cli_list.get_style_context().add_class('app-list')
        scroll_cli = Gtk.ScrolledWindow()
        scroll_cli.add(self.cli_list)
        
        cli_frame = Gtk.Frame()
        cli_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        cli_header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        cli_header_box.set_margin_top(15)
        cli_header_box.set_margin_bottom(10)
        cli_header_box.set_margin_start(10)
        cli_header_box.set_margin_end(10)
        lbl_cli = Gtk.Label(label="<span color='white'>Terminal Applications</span>", use_markup=True)
        lbl_cli.get_style_context().add_class('title-lbl')
        self.cli_range_lbl = Gtk.Label(label=" (1-1000)")
        
        cli_jump_top = Gtk.Button(label="↑ Prev 1000")
        cli_jump_top.connect("clicked", lambda w: self.on_paginate(is_terminal=True, forward=False))
        cli_jump_bottom = Gtk.Button(label="↓ Next 1000")
        cli_jump_bottom.connect("clicked", lambda w: self.on_paginate(is_terminal=True, forward=True))
        
        cli_add_btn = Gtk.Button(label="+ Add")
        cli_add_btn.connect("clicked", lambda w: self.on_add_clicked(is_terminal=True))
        cli_add_btn.get_style_context().add_class('suggested-action')
        
        cli_header_box.pack_start(lbl_cli, False, False, 0)
        cli_header_box.pack_start(self.cli_range_lbl, False, False, 0)
        
        # Spacer
        cli_spacer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        cli_spacer.set_hexpand(True)
        cli_header_box.pack_start(cli_spacer, True, True, 0)
        
        cli_header_box.pack_start(cli_jump_top, False, False, 0)
        cli_header_box.pack_start(cli_jump_bottom, False, False, 0)
        cli_header_box.pack_start(cli_add_btn, False, False, 0)
        
        cli_box.pack_start(cli_header_box, False, False, 0)
        cli_box.pack_start(scroll_cli, True, True, 0)
        
        # Connect scroll event for CLI list
        scroll_cli.get_vadjustment().connect("value-changed", self.on_cli_scroll)
        
        self.scroll_cli = scroll_cli # Keep reference
        cli_frame.add(cli_box)
        self.panels_box.pack_start(cli_frame, True, True, 0)
        
        self.stack.add_named(self.panels_box, "all")
        
        # Page 3: Live Scan View
        self.scan_list = Gtk.ListBox()
        self.scan_list.get_style_context().add_class('app-list')
        scroll_scan = Gtk.ScrolledWindow()
        scroll_scan.add(self.scan_list)
        
        scan_frame = Gtk.Frame()
        scan_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        
        scan_header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        scan_header_box.set_margin_top(15)
        scan_header_box.set_margin_bottom(10)
        scan_header_box.set_margin_start(10)
        scan_header_box.set_margin_end(10)
        
        lbl_scan = Gtk.Label(label="<span font='14' weight='bold' color='white'>Live Scan Results</span>", use_markup=True)
        scan_header_box.pack_start(lbl_scan, False, False, 0)
        
        self.stop_scan_btn = Gtk.Button(label="Stop Scan")
        self.stop_scan_btn.connect("clicked", self.on_stop_scan_clicked)
        self.stop_scan_btn.get_style_context().add_class('destructive-action')
        self.stop_scan_btn.set_sensitive(False)
        scan_header_box.pack_end(self.stop_scan_btn, False, False, 0)
        
        scan_box.pack_start(scan_header_box, False, False, 0)
        
        self.scan_progress = Gtk.ProgressBar()
        self.scan_progress.set_show_text(True)
        self.scan_progress.set_margin_start(10)
        self.scan_progress.set_margin_end(10)
        self.scan_progress.set_margin_bottom(5)
        scan_box.pack_start(self.scan_progress, False, False, 0)
        
        scan_box.pack_start(scroll_scan, True, True, 0)
        scan_frame.add(scan_box)
        
        self.stack.add_named(scan_frame, "scan")
        
        self.main_container.pack_start(self.stack, True, True, 0)

        # Bottom Bar: Recent apps & Spinner
        self.recent_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.recent_box.set_margin_top(10)
        lbl_recent = Gtk.Label(label="<span size='large' color='gray'>Recently Used:</span>", use_markup=True)
        self.recent_box.pack_start(lbl_recent, False, False, 0)
        
        close_btn = Gtk.Button.new_from_icon_name('window-close-symbolic', Gtk.IconSize.MENU)
        close_btn.set_tooltip_text("Close Launcher")
        close_btn.connect("clicked", lambda w: self.close())
        close_btn.get_style_context().add_class('system-action')
        
        restart_btn = Gtk.Button.new_from_icon_name('view-refresh-symbolic', Gtk.IconSize.MENU)
        restart_btn.set_tooltip_text("Restart Launcher")
        restart_btn.connect("clicked", self.on_restart_clicked)
        restart_btn.get_style_context().add_class('system-action')
        
        self.recent_box.pack_end(close_btn, False, False, 0)
        self.recent_box.pack_end(restart_btn, False, False, 0)
        
        self.spinner = Gtk.Spinner()
        self.recent_box.pack_end(self.spinner, False, False, 0)
        
        self.main_container.pack_start(self.recent_box, False, False, 0)

        self.populate_lists()
        
        if self.db.is_empty():
            self.show_initial_scan_prompt()
            
        self.show_all()

    def show_initial_scan_prompt(self):
        # Notify the user that they should run a scan for the first time
        lbl = Gtk.Label(label="<span font='14' weight='bold' color='#729fcf'>Welcome! Click 'Scan System' to find your applications for the first time.</span>", use_markup=True)
        lbl.set_margin_top(20)
        lbl.set_margin_bottom(20)
        self.scan_list.add(lbl)
        self.stack.set_visible_child_name("scan")
        self.toggle_stack_btn.set_label("Back")
        lbl.show_all()
        
    def on_initial_scan_finished(self):
        def _update_ui():
            self.populate_lists(self.search_entry.get_text())
            if hasattr(self, 'scan_btn'):
                self.scan_btn.set_sensitive(True)
            if hasattr(self, 'stop_scan_btn'):
                self.stop_scan_btn.set_sensitive(False)
            
            # Auto-switch to "all" apps view once scan is done to show results
            self.stack.set_visible_child_name("all")
            self.toggle_stack_btn.set_label("Back")
            
            self.stop_spinner()
            return False
        GLib.idle_add(_update_ui)
        
    def on_app_discovered(self, app):
        def _add():
            if hasattr(self, 'scan_list'):
                row = self.create_app_row(app)
                self.scan_list.add(row)
                row.show_all()
            return False
        # Throttle live scan updates slightly to avoid UI thrashing
        GLib.timeout_add(10, _add)
        
    def on_scan_progress(self, text):
        def _update():
            if hasattr(self, 'scan_progress'):
                self.scan_progress.set_text(text)
                self.scan_progress.pulse()
            return False
        GLib.idle_add(_update)
        
    def on_stop_scan_clicked(self, widget):
        if self.detector.running:
            self.detector.stop_scan()
            self.stop_scan_btn.set_sensitive(False)
            self.scan_progress.set_text("Stopping scan...")

    def on_scan_clicked(self, widget):
        if not self.detector.running:
            if hasattr(self, 'scan_btn'):
                self.scan_btn.set_sensitive(False)
            self.spinner.start()
            self.spinner.show()
            
            self.stack.set_visible_child_name("scan")
            self.toggle_stack_btn.set_label("Back")
            self.stop_scan_btn.set_sensitive(True)
            for child in self.scan_list.get_children():
                self.scan_list.remove(child)
            self.scan_progress.set_text("Starting scan...")
            self.scan_progress.set_fraction(0.0)
            
            self.detector.start_background_scan()

    def on_toggle_stack(self, widget):
        current = self.stack.get_visible_child_name()
        if current in ["pinned", "scan"]:
            self.stack.set_visible_child_name("all")
            self.toggle_stack_btn.set_label("Back")
        else:
            self.stack.set_visible_child_name("pinned")
            self.toggle_stack_btn.set_label("All Apps")
            
    def on_restart_clicked(self, widget):
        import sys
        # Use the absolute path of the current main.py to ensure it restarts the new version
        main_py = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'main.py')
        os.execl(sys.executable, sys.executable, main_py, *sys.argv[1:])

    def on_mouse_enter(self, widget, event):
        if event.detail != Gdk.NotifyType.INFERIOR:
            self.main_container.get_style_context().remove_class('dimmed')

    def on_mouse_leave(self, widget, event):
        if event.detail != Gdk.NotifyType.INFERIOR:
            self.main_container.get_style_context().add_class('dimmed')

    def setup_css(self):
        css = f'''
        window {{ background-color: #010206; border-radius: 12px; }}
        #main-container {{
            transition: opacity 0.4s ease-in-out;
            opacity: 1.0;
        }}
        #main-container.dimmed {{
            opacity: 0.1;
        }}
        entry {{
            background-color: rgba(20, 25, 40, 0.8);
            color: white;
            border-radius: 8px;
            padding: 12px;
            border: 1px solid #2a3556;
        }}
        frame {{
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            background-color: rgba(10, 15, 30, 0.4);
        }}
        .app-list {{ background-color: transparent; }}
        eventbox {{
            padding: 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            color: white;
            transition: all 0.2s ease-in-out;
        }}
        eventbox:hover {{ background-color: rgba(40, 60, 100, 0.5); border-radius: 6px; }}
        .app-row {{ 
            background-color: transparent; 
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }}
        .app-row:hover {{ background-color: rgba(255, 255, 255, 0.05); }}
        button {{
            padding: 6px 12px;
            border-radius: 6px;
            background-color: rgba(25, 30, 50, 0.8);
            border: 1px solid #3a4566;
            color: #d1d1d1;
        }}
        button:hover {{
            background-color: rgba(40, 50, 80, 0.9);
            color: white;
        }}
        .suggested-action {{ 
            background-color: #204a87; 
            color: white; 
            border: none;
        }}
        .suggested-action:hover {{ background-color: #3465a4; }}
        button.destructive-action {{ background-color: #8c1a1a; color: white; }}
        button.system-action {{
            background-color: transparent;
            color: gray;
            border: none;
            padding: 4px;
        }}
        button.system-action:hover {{
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 6px;
        }}
        scrollbars {{ opacity: 0.2; }}
        '''
        provider = Gtk.CssProvider()
        provider.load_from_data(css.encode('utf-8'))
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

    def populate_lists(self, search_text=""): 
        if hasattr(self, '_gui_pop_id') and self._gui_pop_id:
            GLib.source_remove(self._gui_pop_id)
        if hasattr(self, '_cli_pop_id') and self._cli_pop_id:
            GLib.source_remove(self._cli_pop_id)

        # Clear existing entries
        for child in self.gui_list.get_children():
            self.gui_list.remove(child)
        for child in self.cli_list.get_children():
            self.cli_list.remove(child)
        for child in self.pinned_list.get_children():
            self.pinned_list.remove(child)

        self.gui_start_offset = 0
        self.gui_end_offset = 0
        self.cli_start_offset = 0
        self.cli_end_offset = 0
        self.current_search_text = search_text.lower().strip()
        
        # Pinned apps are always shown independently
        pinned_apps = [a for a in self.db.get_all_apps() if a.get('is_pinned')]
        for app in pinned_apps:
            row = self.create_app_row(app)
            self.pinned_list.add(row)
        
        self.load_next_gui()
        self.load_next_cli()

    def on_gui_scroll(self, adj):
        val = adj.get_value()
        page = adj.get_page_size()
        upper = adj.get_upper()
        
        # Load next (Down)
        if val + page > upper - 150:
            if not self.loading_gui:
                self.load_next_gui()
        # Load previous (Up)
        elif val < 150 and self.gui_start_offset > 0:
            if not self.loading_gui:
                self.load_prev_gui()

    def on_cli_scroll(self, adj):
        val = adj.get_value()
        page = adj.get_page_size()
        upper = adj.get_upper()
        
        # Load next (Down)
        if val + page > upper - 150:
            if not self.loading_cli:
                self.load_next_cli()
        # Load previous (Up)
        elif val < 150 and self.cli_start_offset > 0:
            if not self.loading_cli:
                self.load_prev_cli()

    def load_next_gui(self):
        self.loading_gui = True
        
        if not self.current_search_text:
            apps = self.db.get_apps_by_terminal_status(is_terminal=False, limit=self.BATCH_SIZE, offset=self.gui_end_offset)
        else:
            apps = self.db.search_apps_by_terminal_status(self.current_search_text, is_terminal=False, limit=self.BATCH_SIZE, offset=self.gui_end_offset)
            
        if apps:
            self.gui_end_offset += len(apps)
            
            # Disable sliding window for pagination logic
            self.add_apps_chunked(apps, self.gui_list, False, 0)
        else:
            self.loading_gui = False

    def load_prev_gui(self):
        self.loading_gui = True
        new_start = max(0, self.gui_start_offset - self.BATCH_SIZE)
        count = self.gui_start_offset - new_start
        
        if count <= 0:
            self.loading_gui = False
            return
            
        if not self.current_search_text:
            apps = self.db.get_apps_by_terminal_status(is_terminal=False, limit=count, offset=new_start)
        else:
            apps = self.db.search_apps_by_terminal_status(self.current_search_text, is_terminal=False, limit=count, offset=new_start)
            
        if apps:
            self.gui_start_offset = new_start
            
            # If exceeding limit, remove from bottom
            children = self.gui_list.get_children()
            if len(children) + len(apps) > self.WINDOW_SIZE:
                to_remove = len(apps)
                total = len(children)
                for i in range(total - to_remove, total):
                    self.gui_list.remove(children[i])
                self.gui_end_offset -= to_remove
            
            # Prepend (which will shift the user view, needing adjustment)
            self.add_apps_chunked(apps, self.gui_list, True, 0)
        else:
            self.loading_gui = False

    def load_next_cli(self):
        self.loading_cli = True
        
        if not self.current_search_text:
            apps = self.db.get_apps_by_terminal_status(is_terminal=True, limit=self.BATCH_SIZE, offset=self.cli_end_offset)
        else:
            apps = self.db.search_apps_by_terminal_status(self.current_search_text, is_terminal=True, limit=self.BATCH_SIZE, offset=self.cli_end_offset)
            
        if apps:
            self.cli_end_offset += len(apps)
            
            # Disable sliding window for pagination
            self.add_apps_chunked(apps, self.cli_list, False, 0)
        else:
            self.loading_cli = False

    def load_prev_cli(self):
        self.loading_cli = True
        new_start = max(0, self.cli_start_offset - self.BATCH_SIZE)
        count = self.cli_start_offset - new_start
        
        if count <= 0:
            self.loading_cli = False
            return
            
        if not self.current_search_text:
            apps = self.db.get_apps_by_terminal_status(is_terminal=True, limit=count, offset=new_start)
        else:
            apps = self.db.search_apps_by_terminal_status(self.current_search_text, is_terminal=True, limit=count, offset=new_start)
            
        if apps:
            self.cli_start_offset = new_start
            
            children = self.cli_list.get_children()
            if len(children) + len(apps) > self.WINDOW_SIZE:
                to_remove = len(apps)
                total = len(children)
                for i in range(total - to_remove, total):
                    self.cli_list.remove(children[i])
                self.cli_end_offset -= to_remove
                
            self.add_apps_chunked(apps, self.cli_list, True, 0)
        else:
            self.loading_cli = False

    def add_apps_chunked(self, apps, target_list, prepend, index):
        CHUNK_SIZE = 80 
        end_index = min(index + CHUNK_SIZE, len(apps))
        
        # We need to maintain the visual focus during prepend/removal
        adj = self.scroll_gui.get_vadjustment() if target_list == self.gui_list else self.scroll_cli.get_vadjustment()
        old_val = adj.get_value()
        old_upper = adj.get_upper()

        for i in range(index, end_index):
            app = apps[i]
            row = self.create_app_row(app)
            if prepend:
                target_list.insert(row, i)
            else:
                target_list.add(row)
        
        target_list.show_all()
        
        # Compensing for top changes during prepending
        if prepend:
            new_upper = adj.get_upper()
            diff = new_upper - old_upper
            adj.set_value(old_val + diff)
            
        while Gtk.events_pending():
            Gtk.main_iteration()
        
        if end_index < len(apps):
            if target_list == self.gui_list:
                self._gui_pop_id = GLib.idle_add(self.add_apps_chunked, apps, target_list, prepend, end_index)
            else:
                self._cli_pop_id = GLib.idle_add(self.add_apps_chunked, apps, target_list, prepend, end_index)
        else:
            if target_list == self.gui_list:
                self.loading_gui = False
                self._gui_pop_id = None
            else:
                self.loading_cli = False
                self._cli_pop_id = None
        return False

    def create_app_row(self, app):
        row = Gtk.ListBoxRow()
        row.set_hexpand(True)
        row_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        row_box.set_margin_top(12)
        row_box.set_margin_bottom(12)
        row_box.set_margin_start(12)
        row_box.set_margin_end(12)
        row_box.set_hexpand(True)

        # Revert to system icons as requested
        icon_theme = Gtk.IconTheme.get_default()
        icon_name = app.get('icon', 'application-x-executable')
        if not icon_name or not icon_theme.has_icon(icon_name):
            # Check if it's an absolute path
            if icon_name and os.path.isabs(icon_name) and os.path.exists(icon_name):
                try:
                    pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(icon_name, 42, 42, True)
                    img = Gtk.Image.new_from_pixbuf(pixbuf)
                except:
                    img = Gtk.Image.new_from_icon_name("application-x-executable", Gtk.IconSize.DND)
            else:
                img = Gtk.Image.new_from_icon_name("application-x-executable", Gtk.IconSize.DND)
        else:
            img = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DND)
            
        row_box.pack_start(img, False, False, 0)

        # Labels box (Expandable)
        text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text_box.set_hexpand(True)
        
        name_lbl = Gtk.Label(label=f"<span color='white'>{app['name']}</span>", use_markup=True)
        name_lbl.set_halign(Gtk.Align.START)
        name_lbl.set_ellipsize(Pango.EllipsizeMode.END)
        name_lbl.get_style_context().add_class('app-name-lbl')
        
        path_lbl = Gtk.Label(label=f"<span color='gray'>{app['exec_path']}</span>", use_markup=True)
        path_lbl.set_halign(Gtk.Align.START)
        path_lbl.set_ellipsize(Pango.EllipsizeMode.END)
        
        text_box.pack_start(name_lbl, False, False, 0)
        text_box.pack_start(path_lbl, False, False, 0)
        row_box.pack_start(text_box, True, True, 0)

        # Status Label
        usage = app.get('usage_count', 0)
        usage_text = f"{usage} uses" if usage > 0 else "Never used"
        status_lbl = Gtk.Label(label=f"<span color='gray'>{usage_text}</span>", use_markup=True)
        row_box.pack_end(status_lbl, False, False, 0)

        event_box = Gtk.EventBox()
        event_box.add(row_box)
        event_box.connect('button-press-event', self.on_app_button_press, app, row)
        row.add(event_box)
        row.get_style_context().add_class('app-row')
        row.show_all()
        return row

    def on_window_resize(self, widget, allocation):
        # Fluid Design: Scale elements based on width to fit everything
        width = allocation.width
        
        # 1. Dynamic Spacing (Aggressive for small windows)
        if width < 700:
            spacing = max(0, int((width - 600) / 20)) # Goes to 0 at 600px
            margin = max(2, int((width - 600) / 10))
        else:
            spacing = max(5, min(15, int(width / 70)))
            margin = max(10, min(20, int(width / 50)))
        
        self.top_bar.set_spacing(spacing)
        self.main_container.set_spacing(spacing)
        self.main_container.set_margin_start(margin)
        self.main_container.set_margin_end(margin)
        self.panels_box.set_spacing(spacing * 2)
        
        # 2. Dynamic CSS for Font and Padding (Aggressive Scaling)
        # Font scales from 12pt (large) to 6pt (tiny)
        font_size = max(6, min(12, int(width / 85)))
        title_size = max(8, min(14, int(width / 75)))
        btn_padding_x = max(1, min(14, int(width / 80) - 2))
        btn_padding_y = max(1, min(8, int(width / 130)))
        
        fluid_css = f"""
            label {{ font-size: {font_size}pt; }}
            .app-list label {{ font-size: {max(5, font_size-2)}pt; opacity: 0.9; }}
            label.title-lbl {{ font-size: {title_size}pt; font-weight: bold; color: white; }}
            label.app-name-lbl {{ font-size: {font_size}pt; font-weight: bold; color: white; }}
            button {{ 
                padding: {btn_padding_y}px {btn_padding_x}px; 
                font-size: {font_size}pt; 
                border-radius: {max(2, int(width/200))}px;
            }}
            entry {{ font-size: {font_size+1}pt; padding: {btn_padding_y}px; }}
        """
        self.css_provider.load_from_data(fluid_css.encode())

    def on_search_changed(self, entry):
        if self._search_timeout_id:
            GLib.source_remove(self._search_timeout_id)
        
        # Debounce: Wait 300ms before triggering database search
        self._search_timeout_id = GLib.timeout_add(300, self.do_search_debounced, entry.get_text())
        
    def do_search_debounced(self, text):
        self.populate_lists(text)
        self._search_timeout_id = None
        return False # Returning False stops the timeout
        
    def on_add_clicked(self, is_terminal=False):
        dialog = Gtk.FileChooserDialog(
            title="Please choose EXECUTABLE files", parent=self,
            action=Gtk.FileChooserAction.OPEN,
            buttons=(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OPEN, Gtk.ResponseType.OK))
        dialog.set_select_multiple(True)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            filenames = dialog.get_filenames()
            for filename in filenames:
                app = {
                    'name': os.path.basename(filename),
                    'exec_path': filename,
                    'icon': 'application-x-executable',
                    'is_terminal': is_terminal,
                    'type': 'custom',
                    'is_custom': True,
                    'is_pinned': False
                }
                self.db.insert_or_update_app(app)
            self.populate_lists(self.search_entry.get_text())
        dialog.destroy()
        
    def on_bind_command_clicked(self, widget):
        text = self.search_entry.get_text().strip()
        if not text:
            dialog = Gtk.MessageDialog(
                transient_for=self, flags=0, message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK, text="Please enter a terminal command in the search bar first."
            )
            dialog.run()
            dialog.destroy()
            return

        command_name = text.split(" ")[0] if " " in text else text

        app = {
            'name': f"Cmd: {command_name}",
            'exec_path': text,
            'icon': 'utilities-terminal',
            'is_terminal': True,
            'type': 'custom',
            'is_custom': True,
            'is_pinned': True
        }
        self.db.insert_or_update_app(app)
        
        # Run the command immediately
        self.spinner.start()
        self.spinner.show()
        launch_app(app)
        self.db.record_launch(app['exec_path'])
        
        
        self.populate_lists()
        self.search_entry.set_text("")
        GLib.timeout_add(1500, self.stop_spinner)

    def on_edit_pinned_clicked(self, widget):
        dialog = Gtk.Dialog(title="Edit Pinned Applications", transient_for=self, flags=0)
        dialog.add_buttons(Gtk.STOCK_CLOSE, Gtk.ResponseType.CLOSE)
        dialog.set_default_size(500, 400)
        
        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        
        lbl = Gtk.Label(label="Manage your pinned applications and commands here.")
        box.pack_start(lbl, False, False, 0)
        
        listbox = Gtk.ListBox()
        scroll = Gtk.ScrolledWindow()
        scroll.add(listbox)
        box.pack_start(scroll, True, True, 0)
        
        apps = [a for a in self.db.get_all_apps() if a.get('is_pinned')]
        for app in apps:
            row = Gtk.ListBoxRow()
            rbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            
            icon_theme = Gtk.IconTheme.get_default()
            icon_name = app.get('icon', 'application-x-executable')
            if not icon_name or not icon_theme.has_icon(icon_name):
                icon_name = 'application-x-executable'
            icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DND)
            rbox.pack_start(icon, False, False, 0)

            llbl = Gtk.Label(label=app['name'])
            llbl.set_halign(Gtk.Align.START)
            rbox.pack_start(llbl, True, True, 0)
            
            unpin_btn = Gtk.Button(label="Unpin")
            unpin_btn.connect("clicked", self.on_dialog_unpin_clicked, app, row, listbox)
            rbox.pack_end(unpin_btn, False, False, 0)
            
            del_btn = Gtk.Button(label="Delete App")
            del_btn.get_style_context().add_class("destructive-action")
            del_btn.connect("clicked", self.on_dialog_delete_clicked, app, row, listbox)
            rbox.pack_end(del_btn, False, False, 0)
            
            row.add(rbox)
            listbox.add(row)
            
        dialog.show_all()
        dialog.run()
        dialog.destroy()
        self.populate_lists()

    def on_dialog_unpin_clicked(self, btn, app, row, listbox):
        self.db.toggle_pin_app(app['exec_path'])
        listbox.remove(row)
        
    def on_dialog_delete_clicked(self, btn, app, row, listbox):
        conf_dialog = Gtk.MessageDialog(
            transient_for=self, flags=0, message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Are you sure you want to permanently delete '{app['name']}'?"
        )
        conf_dialog.get_widget_for_response(Gtk.ResponseType.YES).get_style_context().add_class("destructive-action")
        response = conf_dialog.run()
        conf_dialog.destroy()
        if response == Gtk.ResponseType.YES:
            self.db.remove_app(app['exec_path'])
            listbox.remove(row)

    def on_app_button_press(self, event_box, event, app, row):
        if event.button == 1: 
            self.spinner.start()
            self.spinner.show()
            launch_app(app)
            self.db.record_launch(app['exec_path'])
            self.populate_lists(self.search_entry.get_text())
            GLib.timeout_add(1500, self.stop_spinner)
            
        elif event.button == 3:
            menu = Gtk.Menu()
            
            run_item = Gtk.MenuItem(label="Run")
            run_item.connect("activate", lambda w: self.on_app_button_press(event_box, Gdk.EventButton(button=1), app, row))
            menu.append(run_item)
            
            pin_label = "Unpin from Main View" if app.get('is_pinned') else "Pin to Main View"
            pin_item = Gtk.MenuItem(label=pin_label)
            pin_item.connect("activate", self.on_pin_toggled, app)
            menu.append(pin_item)
            
            remove_item = Gtk.MenuItem(label="Remove App")
            remove_item.connect("activate", self.on_remove_clicked, app, row)
            menu.append(remove_item)
            
            menu.show_all()
            menu.popup(None, None, None, None, event.button, event.time)

    def stop_spinner(self):
        self.spinner.stop()
        self.spinner.hide()
        return False

    def on_pin_toggled(self, widget, app):
        self.db.toggle_pin_app(app['exec_path'])
        self.populate_lists(self.search_entry.get_text())

    def on_remove_clicked(self, widget, app, row):
        dialog = Gtk.MessageDialog(
            transient_for=self, flags=0, message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.OK_CANCEL,
            text=f"First Warning: Are you sure you want to remove '{app['name']}' from the launcher?"
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.OK:
            dialog2 = Gtk.MessageDialog(
                transient_for=self, flags=0, message_type=Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.YES_NO,
                text=f"Final Warning: Delete '{app['name']}' permanently from Manager Launcher?"
            )
            dialog2.get_widget_for_response(Gtk.ResponseType.YES).get_style_context().add_class("destructive-action")
            res2 = dialog2.run()
            dialog2.destroy()
            
            if res2 == Gtk.ResponseType.YES:
                self.db.remove_app(app['exec_path'])
                self.populate_lists(self.search_entry.get_text())

    def on_paginate(self, is_terminal, forward):
        PAGE_SIZE = 1000
        if is_terminal:
            if forward:
                total = self.db.get_apps_count_by_terminal_status(is_terminal=True, search_text=self.current_search_text)
                if self.cli_start_offset + PAGE_SIZE < total:
                    self.cli_start_offset += PAGE_SIZE
            else:
                self.cli_start_offset = max(0, self.cli_start_offset - PAGE_SIZE)
            
            self.cli_end_offset = self.cli_start_offset
            self.cli_range_lbl.set_text(f" ({self.cli_start_offset + 1}-{self.cli_start_offset + PAGE_SIZE})")
            
            if hasattr(self, '_cli_pop_id') and self._cli_pop_id:
                GLib.source_remove(self._cli_pop_id)
            for child in self.cli_list.get_children():
                self.cli_list.remove(child)
            
            self.load_next_cli()
            self.scroll_cli.get_vadjustment().set_value(0)
        else:
            if forward:
                total = self.db.get_apps_count_by_terminal_status(is_terminal=False, search_text=self.current_search_text)
                if self.gui_start_offset + PAGE_SIZE < total:
                    self.gui_start_offset += PAGE_SIZE
            else:
                self.gui_start_offset = max(0, self.gui_start_offset - PAGE_SIZE)
            
            self.gui_end_offset = self.gui_start_offset
            self.gui_range_lbl.set_text(f" ({self.gui_start_offset + 1}-{self.gui_start_offset + PAGE_SIZE})")
            
            if hasattr(self, '_gui_pop_id') and self._gui_pop_id:
                GLib.source_remove(self._gui_pop_id)
            for child in self.gui_list.get_children():
                self.gui_list.remove(child)
                
            self.load_next_gui()
            self.scroll_gui.get_vadjustment().set_value(0)

    # Replace on_jump with on_paginate logic
    def on_jump(self, is_terminal, to_top):
        pass
