#!/bin/bash
echo "Installing Manager Launcher System Dependencies..."

sudo apt-get update
sudo apt-get install -y python3-gi python3-gi-cairo gir1.2-gtk-3.0 gnome-terminal libcairo2-dev python3-pip

echo "Installing GNOME Extension..."
EXT_DIR=~/.local/share/gnome-shell/extensions/manager-launcher@kali.org
mkdir -p "$EXT_DIR"
cp -r gnome-extension/manager-launcher@kali.org/* "$EXT_DIR"/

chmod +x run.sh main.py background_service.py

echo "Setting up Background Service Autostart..."
AUTOSTART_DIR=~/.config/autostart
mkdir -p "$AUTOSTART_DIR"
cat <<EOF > "$AUTOSTART_DIR/manager-launcher-service.desktop"
[Desktop Entry]
Type=Application
Exec=python3 "$(pwd)/background_service.py"
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
Name=Manager Launcher Service
Comment=Detects newly installed applications for Manager Launcher
EOF

echo "Extension installed."
echo "Please log out and log back in, or restart GNOME shell (Alt+F2, type 'r', enter on X11)."
echo "Then enable it by running: gnome-extensions enable manager-launcher@kali.org"
echo "Installation complete! Manager Launcher is ready to run."

# Kill existing instance if any
pkill -f "background_service.py" || true

# Start the background service immediately
nohup python3 "$(pwd)/background_service.py" &>/dev/null &
