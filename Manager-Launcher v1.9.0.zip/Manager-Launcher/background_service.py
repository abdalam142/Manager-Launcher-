#!/usr/bin/env python3
import sys
import os
import time

import gi
gi.require_version('GLib', '2.0')
gi.require_version('Gio', '2.0')
gi.require_version('Notify', '0.7')
from gi.repository import GLib, Gio, Notify

# Ensure the core and engine are importable
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.db import DatabaseManager
from engine.detector import parse_desktop_file

db = DatabaseManager()
seen_recently = {}

def pin_add_app(notification, action, exec_path):
    print(f"Adding application to launcher: {exec_path}")
    # Update the DB
    with db.conn:
        db.conn.execute('UPDATE apps SET is_pinned = 1 WHERE exec_path = ?', (exec_path,))
        if db.conn.changes() == 0:
            # If for some reason the app doesn't exist, we skip
            pass

    # Give the user feedback
    conf_notif = Notify.Notification.new("App Added", "The application has been added to your pinned applications.", "dialog-information")
    conf_notif.show()

def on_desktop_file_changed(monitor, file, other_file, event_type):
    global seen_recently

    if event_type == Gio.FileMonitorEvent.CHANGES_DONE_HINT or event_type == Gio.FileMonitorEvent.CREATED:
        filepath = file.get_path()
        if not filepath or not filepath.endswith('.desktop'):
            return

        # Debounce logic to prevent duplicate notifications during copy/install
        now = time.time()
        if filepath in seen_recently and now - seen_recently[filepath] < 3.0:
            return
        seen_recently[filepath] = now
        
        # Add a tiny delay to ensure file write is complete
        GLib.timeout_add(1000, process_new_desktop_file, filepath)

def process_new_desktop_file(filepath):
    # Parse the application
    app_data = parse_desktop_file(filepath)
    if not app_data or not app_data.get('exec'):
        return False # Returning False stops the GLib timeout

    # Check if this app was already in DB
    with db.conn:
        cursor = db.conn.execute('SELECT is_pinned FROM apps WHERE exec_path = ?', (app_data['exec_path'],))
        row = cursor.fetchone()
        
    already_existed = row is not None

    if already_existed and row['is_pinned']:
        # Already pinned, ignore
        return False
        
    # Insert or update
    db.insert_or_update_app(app_data)
    
    # Show notification prompting to pin
    icon_name = app_data.get('icon', 'application-x-executable')
    notif = Notify.Notification.new(
        "Manager Launcher",
        f"New application detected: {app_data['name']}\nWould you like to add it to your apps list?",
        icon_name
    )
    
    notif.add_action("add_app", "Add Application", pin_add_app, app_data['exec_path'])
    notif.show()
    return False

def main():
    if not Notify.init("Manager Launcher Service"):
        print("Failed to initialize libnotify.")
        sys.exit(1)
        
    monitor_dirs = [
        '/usr/share/applications',
        os.path.expanduser('~/.local/share/applications'),
        '/usr/local/share/applications'
    ]
    
    monitors = []
    
    for d in monitor_dirs:
        if os.path.exists(d):
            gfile = Gio.File.new_for_path(d)
            monitor = gfile.monitor_directory(Gio.FileMonitorFlags.NONE, None)
            monitor.connect('changed', on_desktop_file_changed)
            monitors.append(monitor)
            print(f"Monitoring: {d}")
            
    loop = GLib.MainLoop()
    try:
        loop.run()
    except KeyboardInterrupt:
        pass
    finally:
        Notify.uninit()

if __name__ == '__main__':
    main()
