import sqlite3
import os
from .config import DB_PATH

class DatabaseManager:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._create_tables()

    def _create_tables(self):
        with self.conn:
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS apps (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    exec_path TEXT NOT NULL,
                    icon TEXT,
                    is_terminal BOOLEAN NOT NULL DEFAULT 0,
                    type TEXT,
                    last_used TIMESTAMP,
                    usage_count INTEGER DEFAULT 0,
                    is_custom BOOLEAN DEFAULT 0,
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    category TEXT,
                    is_pinned BOOLEAN DEFAULT 0,
                    file_mtime REAL DEFAULT 0
                )
            ''')
            
            # Add missing columns to existing databases
            try:
                self.conn.execute('ALTER TABLE apps ADD COLUMN is_pinned BOOLEAN DEFAULT 0')
            except sqlite3.OperationalError:
                pass
            
            try:
                self.conn.execute('ALTER TABLE apps ADD COLUMN file_mtime REAL DEFAULT 0')
            except sqlite3.OperationalError:
                pass

            self.conn.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_exec_path ON apps(exec_path)')
            self.conn.execute('CREATE INDEX IF NOT EXISTS idx_file_mtime ON apps(file_mtime)')

    def insert_or_update_app(self, app_data):
        with self.conn:
            try:
                self.conn.execute('''
                    INSERT INTO apps (name, exec_path, icon, is_terminal, type, is_custom, category, is_pinned, file_mtime)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (app_data['name'], app_data['exec_path'], app_data.get('icon', ''),
                      app_data.get('is_terminal', False), app_data.get('type', 'system'),
                      app_data.get('is_custom', False), app_data.get('category', ''),
                      app_data.get('is_pinned', False), app_data.get('file_mtime', 0)))
                return True
            except (sqlite3.IntegrityError, sqlite3.DatabaseError):
                if 'is_pinned' in app_data or 'file_mtime' in app_data:
                    self.conn.execute('''
                        UPDATE apps SET 
                        is_pinned = COALESCE(?, is_pinned),
                        file_mtime = COALESCE(?, file_mtime)
                        WHERE exec_path = ?
                    ''', (app_data.get('is_pinned'), app_data.get('file_mtime'), app_data['exec_path']))
                return False
                
    def insert_apps_batch(self, apps_list):
        if not apps_list:
            return
        with self.conn:
            for app_data in apps_list:
                try:
                    self.conn.execute('''
                        INSERT INTO apps (name, exec_path, icon, is_terminal, type, is_custom, category, is_pinned, file_mtime)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (app_data['name'], app_data['exec_path'], app_data.get('icon', ''),
                          app_data.get('is_terminal', False), app_data.get('type', 'system'),
                          app_data.get('is_custom', False), app_data.get('category', ''),
                          app_data.get('is_pinned', False), app_data.get('file_mtime', 0)))
                except (sqlite3.IntegrityError, sqlite3.DatabaseError):
                    if 'is_pinned' in app_data or 'file_mtime' in app_data:
                        self.conn.execute('''
                            UPDATE apps SET 
                            is_pinned = COALESCE(?, is_pinned),
                            file_mtime = COALESCE(?, file_mtime)
                            WHERE exec_path = ?
                        ''', (app_data.get('is_pinned'), app_data.get('file_mtime'), app_data['exec_path']))

    def get_all_apps(self, limit=None, offset=0):
        query = 'SELECT * FROM apps ORDER BY file_mtime DESC, usage_count DESC, added_at DESC'
        if limit:
            query += f' LIMIT {limit} OFFSET {offset}'
        cursor = self.conn.execute(query)
        return [dict(row) for row in cursor.fetchall()]

    def get_apps_by_type(self, app_type, limit=None, offset=0):
        query = 'SELECT * FROM apps WHERE type = ? ORDER BY file_mtime DESC, usage_count DESC, added_at DESC'
        if limit:
            query += f' LIMIT {limit} OFFSET {offset}'
        cursor = self.conn.execute(query, (app_type,))
        return [dict(row) for row in cursor.fetchall()]

    def search_apps(self, search_text, limit=None, offset=0):
        query = "SELECT * FROM apps WHERE name LIKE ? OR exec_path LIKE ? ORDER BY usage_count DESC, file_mtime DESC"
        if limit:
            query += f' LIMIT {limit} OFFSET {offset}'
        cursor = self.conn.execute(query, (f'%{search_text}%', f'%{search_text}%'))
        return [dict(row) for row in cursor.fetchall()]

    def record_launch(self, exec_path):
        with self.conn:
            self.conn.execute('''
                UPDATE apps
                SET usage_count = usage_count + 1, last_used = CURRENT_TIMESTAMP
                WHERE exec_path = ?
            ''', (exec_path,))

    def remove_app(self, exec_path):
        with self.conn:
            self.conn.execute('DELETE FROM apps WHERE exec_path = ?', (exec_path,))

    def toggle_pin_app(self, exec_path):
        with self.conn:
            self.conn.execute('''
                UPDATE apps
                SET is_pinned = NOT is_pinned
                WHERE exec_path = ?
            ''', (exec_path,))
    def get_apps_count_by_terminal_status(self, is_terminal, search_text=""):
        if not search_text:
            query = 'SELECT COUNT(*) FROM apps WHERE is_terminal = ?'
            cursor = self.conn.execute(query, (1 if is_terminal else 0,))
        else:
            query = "SELECT COUNT(*) FROM apps WHERE is_terminal = ? AND (name LIKE ? OR exec_path LIKE ?)"
            cursor = self.conn.execute(query, (1 if is_terminal else 0, f'%{search_text}%', f'%{search_text}%'))
        return cursor.fetchone()[0]

    def is_empty(self):
        cursor = self.conn.execute('SELECT COUNT(*) FROM apps')
        return cursor.fetchone()[0] == 0

    def get_apps_by_terminal_status(self, is_terminal, limit=None, offset=0):
        query = 'SELECT * FROM apps WHERE is_terminal = ? ORDER BY file_mtime DESC, usage_count DESC, added_at DESC'
        if limit:
            query += f' LIMIT {limit} OFFSET {offset}'
        cursor = self.conn.execute(query, (1 if is_terminal else 0,))
        return [dict(row) for row in cursor.fetchall()]

    def search_apps_by_terminal_status(self, search_text, is_terminal, limit=None, offset=0):
        query = "SELECT * FROM apps WHERE is_terminal = ? AND (name LIKE ? OR exec_path LIKE ?) ORDER BY usage_count DESC, file_mtime DESC"
        if limit:
            query += f' LIMIT {limit} OFFSET {offset}'
        cursor = self.conn.execute(query, (1 if is_terminal else 0, f'%{search_text}%', f'%{search_text}%'))
        return [dict(row) for row in cursor.fetchall()]
